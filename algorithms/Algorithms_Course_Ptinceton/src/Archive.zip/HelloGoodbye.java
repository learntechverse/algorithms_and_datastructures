public class HelloGoodbye {
    public static void main(String[] args) {
        System.out.println("Hello "+ args[0] + " " + args[1]);
        System.out.println("Goodbye "+ args[0] + " " + args[1]);
    }
}
